# game
1.按住a键，小松鼠开始跳跃
2.目前游戏时间为30s，可在根目录js.js调整time变量
3.分数存在sessionStorage
